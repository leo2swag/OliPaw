enum UserType { owner, guest, merchant }
enum PetType { dog, cat, other }
enum PostCategory { snapshot, sleepy, walk, play }

class UserProfile {
  final String id;
  final UserType type;
  final String name;
  final String? avatarUrl;
  final String? breed;
  final String? bio;
  final String? spiritAnimal;

  UserProfile({
    required this.id,
    required this.type,
    required this.name,
    this.avatarUrl,
    this.breed,
    this.bio,
    this.spiritAnimal,
  });
}

class Vaccine {
  final String id;
  final String name;
  final String dateAdministered;
  final String dueDate;
  final String veterinarian;

  Vaccine({
    required this.id,
    required this.name,
    required this.dateAdministered,
    required this.dueDate,
    required this.veterinarian,
  });
}

class WeightRecord {
  final String date;
  final double weight;
  WeightRecord(this.date, this.weight);
}

class Pet {
  final String id;
  final String name;
  final PetType type;
  final String breed;
  final String birthDate;
  final String avatarUrl;
  final String bio;
  final List<Vaccine> vaccines;
  final List<WeightRecord> weightHistory;
  final List<String> gallery;
  bool isFollowing;

  Pet({
    required this.id,
    required this.name,
    required this.type,
    required this.breed,
    required this.birthDate,
    required this.avatarUrl,
    required this.bio,
    required this.vaccines,
    required this.weightHistory,
    required this.gallery,
    this.isFollowing = false,
  });
}

class Post {
  final String id;
  final String authorId;
  final String authorName;
  final String authorAvatar;
  final String content;
  final String? imageUrl;
  int likes;
  int comments;
  final String timestamp;
  final String date;
  final String? mood;
  final PostCategory category;
  final String? location;

  Post({
    required this.id,
    required this.authorId,
    required this.authorName,
    required this.authorAvatar,
    required this.content,
    this.imageUrl,
    required this.likes,
    required this.comments,
    required this.timestamp,
    required this.date,
    this.mood,
    required this.category,
    this.location,
  });
}

class ChatMessage {
  final String role; // 'user' or 'model'
  final String text;

  ChatMessage({required this.role, required this.text});
}
