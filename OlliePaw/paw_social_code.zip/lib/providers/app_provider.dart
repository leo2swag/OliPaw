import 'package:flutter/material.dart';
import '../models/types.dart';
import '../data/mock_data.dart';

class AppProvider with ChangeNotifier {
  UserProfile? _user;
  Pet _currentPet = initialPet;
  int _treats = 50;
  List<Post> _posts = List.from(mockPosts);

  UserProfile? get user => _user;
  Pet get currentPet => _currentPet;
  int get treats => _treats;
  List<Post> get posts => _posts;

  bool get isLoggedIn => _user != null;

  void login(UserProfile profile) {
    _user = profile;
    notifyListeners();
  }

  void logout() {
    _user = null;
    notifyListeners();
  }

  bool spendTreats(int amount) {
    if (_treats >= amount) {
      _treats -= amount;
      notifyListeners();
      return true;
    }
    return false;
  }
  
  void addPost(Post post) {
    _posts.insert(0, post);
    notifyListeners();
  }
}
