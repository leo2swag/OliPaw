import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/types.dart';
import '../providers/app_provider.dart';
import '../theme.dart';

class AuthScreen extends StatelessWidget {
  const AuthScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(32.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.pets, size: 80, color: AppTheme.primary),
              const SizedBox(height: 24),
              const Text("PawSocial", style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold)),
              const Text("Loading cuteness...", style: TextStyle(color: Colors.grey)),
              const SizedBox(height: 48),
              ElevatedButton(
                onPressed: () {
                  Provider.of<AppProvider>(context, listen: false).login(
                    UserProfile(
                      id: 'u1', 
                      type: UserType.owner, 
                      name: 'Barnaby Owner',
                      avatarUrl: 'https://picsum.photos/200'
                    )
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.black,
                  foregroundColor: Colors.white,
                  minimumSize: const Size(double.infinity, 50),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                ),
                child: const Text("Enter as Pet Owner"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
