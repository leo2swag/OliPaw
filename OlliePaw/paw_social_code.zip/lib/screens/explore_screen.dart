import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../providers/app_provider.dart';
import '../models/types.dart';
import '../data/mock_data.dart';
import '../theme.dart';
import '../services/gemini_service.dart';
import 'profile_screen.dart';

class ExploreScreen extends StatefulWidget {
  const ExploreScreen({super.key});

  @override
  State<ExploreScreen> createState() => _ExploreScreenState();
}

class _ExploreScreenState extends State<ExploreScreen> {
  String _searchQuery = '';
  final GeminiService _geminiService = GeminiService();

  void _openTimeMachine() async {
    final provider = Provider.of<AppProvider>(context, listen: false);
    
    if (!provider.spendTreats(20)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Need 20 Treats to use Time Machine! 🦴")),
      );
      return;
    }

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => const Center(
        child: Card(
          child: Padding(
            padding: EdgeInsets.all(24.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                CircularProgressIndicator(color: AppTheme.primary),
                SizedBox(height: 16),
                Text("Consulting the Crystal Ball..."),
              ],
            ),
          ),
        ),
      ),
    );

    final prediction = await _geminiService.predictFutureSelf(provider.currentPet);

    if (mounted) {
      Navigator.pop(context); 
      _showPredictionResult(prediction, provider.currentPet);
    }
  }

  void _showPredictionResult(String text, Pet pet) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: Colors.indigo.shade50,
        title: const Row(
          children: [
            Icon(LucideIcons.hourglass, color: Colors.indigo),
            SizedBox(width: 8),
            Text("Future Self"),
          ],
        ),
        content: Text(
          text,
          style: const TextStyle(fontSize: 16, height: 1.5, color: Colors.indigo),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text("Awesome!", style: TextStyle(fontWeight: FontWeight.bold)),
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<AppProvider>(context);
    
    final filteredPets = mockPets.where((pet) =>
      pet.name.toLowerCase().contains(_searchQuery.toLowerCase()) ||
      pet.breed.toLowerCase().contains(_searchQuery.toLowerCase())
    ).toList();

    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text("Discover", style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: Colors.amber.shade50,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: Colors.amber.shade100),
                    ),
                    child: Row(
                      children: [
                        const Icon(LucideIcons.bone, size: 16, color: AppTheme.primary),
                        const SizedBox(width: 4),
                        Text("${provider.treats}", style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.brown)),
                      ],
                    ),
                  )
                ],
              ),
              const SizedBox(height: 16),

              Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(30),
                  boxShadow: [BoxShadow(color: Colors.grey.withOpacity(0.1), blurRadius: 10)],
                  border: Border.all(color: AppTheme.primary.withOpacity(0.3), width: 2),
                ),
                child: TextField(
                  onChanged: (val) => setState(() => _searchQuery = val),
                  decoration: const InputDecoration(
                    hintText: "Search for friends...",
                    prefixIcon: Icon(LucideIcons.search, color: Colors.grey),
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.symmetric(vertical: 14),
                  ),
                ),
              ),
              const SizedBox(height: 24),

              const Row(
                children: [
                  Icon(LucideIcons.zap, size: 18, color: Colors.purple),
                  SizedBox(width: 8),
                  Text("Fun Labs", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                ],
              ),
              const SizedBox(height: 12),
              
              Row(
                children: [
                  Expanded(
                    child: GestureDetector(
                      onTap: _openTimeMachine,
                      child: Container(
                        height: 120,
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(colors: [Colors.indigo, Colors.blue]),
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: [BoxShadow(color: Colors.blue.withOpacity(0.3), blurRadius: 8, offset: const Offset(0, 4))],
                        ),
                        child: const Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Icon(LucideIcons.hourglass, color: Colors.white, size: 28),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text("Growth
Predictor", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, height: 1.1)),
                                SizedBox(height: 4),
                                Text("20 🦴", style: TextStyle(color: Colors.white70, fontSize: 12)),
                              ],
                            )
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Container(
                      height: 120,
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: Colors.grey.shade100),
                      ),
                      child: const Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Icon(LucideIcons.mic, color: Colors.orange, size: 28),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text("Bark
Translator", style: TextStyle(color: Colors.black87, fontWeight: FontWeight.bold, height: 1.1)),
                              SizedBox(height: 4),
                              Text("5 🦴", style: TextStyle(color: Colors.grey, fontSize: 12)),
                            ],
                          )
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 24),

              const Text("Suggested Pals", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              
              ...filteredPets.map((pet) => GestureDetector(
                onTap: () {
                  Navigator.push(
                    context, 
                    MaterialPageRoute(builder: (_) => ProfileScreen(pet: pet))
                  );
                },
                child: Container(
                  margin: const EdgeInsets.only(bottom: 12),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.grey.shade100),
                  ),
                  child: Row(
                    children: [
                      CircleAvatar(
                        radius: 24,
                        backgroundImage: CachedNetworkImageProvider(pet.avatarUrl),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(pet.name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                            Text(pet.breed, style: const TextStyle(color: Colors.grey, fontSize: 12)),
                          ],
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: Colors.amber.shade50,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: const Text("Visit", style: TextStyle(color: Colors.amber, fontWeight: FontWeight.bold, fontSize: 12)),
                      )
                    ],
                  ),
                ),
              )).toList(),
            ],
          ),
        ),
      ),
    );
  }
}
