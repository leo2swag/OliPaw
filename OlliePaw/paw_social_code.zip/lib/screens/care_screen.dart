import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:fl_chart/fl_chart.dart';
import '../providers/app_provider.dart';
import '../services/gemini_service.dart';
import '../models/types.dart';
import '../theme.dart';

class CareScreen extends StatefulWidget {
  const CareScreen({super.key});

  @override
  State<CareScreen> createState() => _CareScreenState();
}

class _CareScreenState extends State<CareScreen> {
  final GeminiService _aiService = GeminiService();
  String _healthTip = "Loading daily tip...";
  final TextEditingController _chatController = TextEditingController();
  final List<ChatMessage> _messages = [];
  bool _isChatLoading = false;

  @override
  void initState() {
    super.initState();
    _loadTip();
  }

  void _loadTip() async {
    final pet = Provider.of<AppProvider>(context, listen: false).currentPet;
    final tip = await _aiService.analyzeHealthTip(pet);
    if (mounted) setState(() => _healthTip = tip);
  }

  void _sendMessage() async {
    if (_chatController.text.isEmpty) return;
    
    final provider = Provider.of<AppProvider>(context, listen: false);
    if (!provider.spendTreats(5)) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Need more treats!")));
      return;
    }

    final userText = _chatController.text;
    setState(() {
      _messages.add(ChatMessage(role: 'user', text: userText));
      _chatController.clear();
      _isChatLoading = true;
    });

    final aiResponse = await _aiService.chatWithVet(userText, provider.currentPet);
    
    if (mounted) {
      setState(() {
        _messages.add(ChatMessage(role: 'model', text: aiResponse));
        _isChatLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text("Care Center", style: TextStyle(fontWeight: FontWeight.bold)),
          backgroundColor: Colors.transparent,
          bottom: const TabBar(
            indicatorColor: AppTheme.primary,
            labelColor: AppTheme.primary,
            tabs: [
              Tab(icon: Icon(LucideIcons.heartPulse), text: "Health"),
              Tab(icon: Icon(LucideIcons.messageCircle), text: "AI Vet"),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            _buildHealthTab(),
            _buildChatTab(),
          ],
        ),
      ),
    );
  }

  Widget _buildHealthTab() {
    final pet = Provider.of<AppProvider>(context).currentPet;
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Colors.teal, Colors.emerald]),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Row(
              children: [
                const Icon(LucideIcons.sparkles, color: Colors.yellow),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text("Dr. AI's Tip", style: TextStyle(color: Colors.white70, fontSize: 12, fontWeight: FontWeight.bold)),
                      Text(_healthTip, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w500)),
                    ],
                  ),
                )
              ],
            ),
          ),
          const SizedBox(height: 20),
          Container(
            height: 200,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
            child: LineChart(
              LineChartData(
                gridData: const FlGridData(show: false),
                titlesData: const FlTitlesData(show: false),
                borderData: FlBorderData(show: false),
                lineBarsData: [
                  LineChartBarData(
                    spots: pet.weightHistory.asMap().entries.map((e) {
                      return FlSpot(e.key.toDouble(), e.value.weight);
                    }).toList(),
                    isCurved: true,
                    color: Colors.orange,
                    barWidth: 4,
                    belowBarData: BarAreaData(show: true, color: Colors.orange.withOpacity(0.2)),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildChatTab() {
    return Column(
      children: [
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: _messages.length,
            itemBuilder: (context, index) {
              final msg = _messages[index];
              final isUser = msg.role == 'user';
              return Align(
                alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
                child: Container(
                  margin: const EdgeInsets.symmetric(vertical: 4),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: isUser ? AppTheme.primary : Colors.white,
                    borderRadius: BorderRadius.circular(16).copyWith(
                      bottomRight: isUser ? const Radius.circular(0) : null,
                      topLeft: !isUser ? const Radius.circular(0) : null,
                    ),
                    boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 4)],
                  ),
                  child: Text(msg.text, style: TextStyle(color: isUser ? Colors.white : Colors.black87)),
                ),
              );
            },
          ),
        ),
        if (_isChatLoading) const LinearProgressIndicator(color: AppTheme.primary),
        Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _chatController,
                  decoration: InputDecoration(
                    hintText: "Ask about health...",
                    filled: true,
                    fillColor: Colors.white,
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(30), borderSide: BorderSide.none),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              IconButton(
                onPressed: _sendMessage,
                icon: const Icon(LucideIcons.send),
                style: IconButton.styleFrom(backgroundColor: AppTheme.primary, foregroundColor: Colors.white),
              )
            ],
          ),
        )
      ],
    );
  }
}
