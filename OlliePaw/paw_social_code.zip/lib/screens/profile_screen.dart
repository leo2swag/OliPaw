import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../providers/app_provider.dart';
import '../models/types.dart';
import '../theme.dart';
import '../data/mock_data.dart';

class ProfileScreen extends StatefulWidget {
  final Pet? pet;
  const ProfileScreen({super.key, this.pet});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  bool _isFollowing = false;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<AppProvider>(context);
    final displayPet = widget.pet ?? provider.currentPet;
    final isOwner = widget.pet == null || widget.pet!.id == provider.currentPet.id;

    return Scaffold(
      body: Column(
        children: [
          Expanded(
            child: NestedScrollView(
              headerSliverBuilder: (context, innerBoxIsScrolled) {
                return [
                  SliverToBoxAdapter(
                    child: _buildProfileHeader(displayPet, isOwner),
                  ),
                  SliverPersistentHeader(
                    delegate: _SliverTabBarDelegate(
                      TabBar(
                        controller: _tabController,
                        labelColor: AppTheme.textMain,
                        unselectedLabelColor: Colors.grey,
                        indicatorColor: AppTheme.primary,
                        tabs: const [
                          Tab(text: "Timeline", icon: Icon(LucideIcons.list)),
                          Tab(text: "Moments", icon: Icon(LucideIcons.layoutGrid)),
                        ],
                      ),
                    ),
                    pinned: true,
                  ),
                ];
              },
              body: TabBarView(
                controller: _tabController,
                children: [
                  _buildTimelineTab(displayPet, isOwner),
                  _buildGalleryTab(displayPet, isOwner),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProfileHeader(Pet pet, bool isOwner) {
    return Stack(
      clipBehavior: Clip.none,
      alignment: Alignment.center,
      children: [
        Column(
          children: [
            Container(
              height: 120,
              width: double.infinity,
              decoration: BoxDecoration(
                color: Colors.amber.shade200,
                borderRadius: const BorderRadius.vertical(bottom: Radius.circular(32)),
              ),
              child: Stack(
                children: [
                   if (!isOwner)
                     Positioned(
                       top: 40, left: 16,
                       child: CircleAvatar(
                         backgroundColor: Colors.white30,
                         child: IconButton(
                           icon: const Icon(LucideIcons.chevronLeft, color: Colors.white),
                           onPressed: () => Navigator.pop(context),
                         ),
                       ),
                     ),
                ],
              ),
            ),
            const SizedBox(height: 60), 
          ],
        ),
        
        Positioned(
          top: 70,
          child: Container(
            padding: const EdgeInsets.all(4),
            decoration: BoxDecoration(color: Colors.white, shape: BoxShape.circle, boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 10)]),
            child: CircleAvatar(
              radius: 50,
              backgroundImage: CachedNetworkImageProvider(pet.avatarUrl),
            ),
          ),
        ),

        Padding(
          padding: const EdgeInsets.fromLTRB(24, 180, 24, 0),
          child: Column(
            children: [
              Text(pet.name, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
              Text(pet.breed, style: const TextStyle(color: Colors.grey, fontWeight: FontWeight.w600)),
              
              const SizedBox(height: 12),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _buildBadge("🎂 2 Years", Colors.amber.shade100, Colors.amber.shade800),
                  const SizedBox(width: 8),
                  _buildBadge("⚖️ 29kg", Colors.blue.shade100, Colors.blue.shade800),
                ],
              ),
              
              const SizedBox(height: 16),
              Text(
                '"${pet.bio}"', 
                textAlign: TextAlign.center,
                style: const TextStyle(fontStyle: FontStyle.italic, color: Colors.black54),
              ),

              const SizedBox(height: 16),
              if (!isOwner)
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () => setState(() => _isFollowing = !_isFollowing),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _isFollowing ? Colors.grey.shade200 : Colors.black,
                      foregroundColor: _isFollowing ? Colors.black : Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    child: Text(_isFollowing ? "Following" : "Follow Buddy"),
                  ),
                ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildBadge(String text, Color bg, Color fg) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(20)),
      child: Text(text, style: TextStyle(color: fg, fontWeight: FontWeight.bold, fontSize: 12)),
    );
  }

  Widget _buildTimelineTab(Pet pet, bool isOwner) {
    final posts = mockPosts.where((p) => isOwner ? true : p.authorId == pet.id).toList();

    return ListView.builder(
      padding: const EdgeInsets.all(20),
      itemCount: posts.length,
      itemBuilder: (context, index) {
        final post = posts[index];
        return IntrinsicHeight(
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Column(
                children: [
                  Container(
                    width: 12, height: 12,
                    decoration: BoxDecoration(
                      color: AppTheme.primary,
                      shape: BoxShape.circle,
                      border: Border.all(color: Colors.white, width: 2),
                      boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 4)]
                    ),
                  ),
                  if (index != posts.length - 1)
                    Expanded(child: Container(width: 2, color: Colors.amber.shade100)),
                ],
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.only(bottom: 24),
                  child: Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: Colors.grey.shade100),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(post.date, style: const TextStyle(fontSize: 12, color: Colors.grey, fontWeight: FontWeight.bold)),
                            const Icon(LucideIcons.heart, size: 14, color: Colors.grey),
                          ],
                        ),
                        const SizedBox(height: 8),
                        if (post.imageUrl != null)
                          ClipRRect(
                            borderRadius: BorderRadius.circular(12),
                            child: Image.network(post.imageUrl!, height: 120, width: double.infinity, fit: BoxFit.cover),
                          ),
                        const SizedBox(height: 8),
                        Text(post.content, style: const TextStyle(fontSize: 14)),
                      ],
                    ),
                  ),
                ),
              )
            ],
          ),
        );
      },
    );
  }

  Widget _buildGalleryTab(Pet pet, bool isOwner) {
    if (!isOwner && !_isFollowing) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(LucideIcons.lock, size: 48, color: Colors.grey),
            const SizedBox(height: 16),
            Text("Follow ${pet.name} to see photos!", style: const TextStyle(color: Colors.grey)),
          ],
        ),
      );
    }

    final images = pet.gallery.isNotEmpty 
        ? pet.gallery 
        : mockPosts.where((p) => p.imageUrl != null).map((p) => p.imageUrl!).toList();

    return GridView.builder(
      padding: const EdgeInsets.all(16),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        crossAxisSpacing: 8,
        mainAxisSpacing: 8,
      ),
      itemCount: images.length,
      itemBuilder: (context, index) {
        return ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: CachedNetworkImage(
            imageUrl: images[index],
            fit: BoxFit.cover,
            placeholder: (context, url) => Container(color: Colors.grey.shade100),
          ),
        );
      },
    );
  }
}

class _SliverTabBarDelegate extends SliverPersistentHeaderDelegate {
  final TabBar _tabBar;
  _SliverTabBarDelegate(this._tabBar);

  @override
  double get minExtent => _tabBar.preferredSize.height;
  @override
  double get maxExtent => _tabBar.preferredSize.height;

  @override
  Widget build(BuildContext context, double shrinkOffset, bool overlapsContent) {
    return Container(
      color: AppTheme.background,
      child: _tabBar,
    );
  }

  @override
  bool shouldRebuild(_SliverTabBarDelegate oldDelegate) => false;
}
