import 'package:google_generative_ai/google_generative_ai.dart';
import '../models/types.dart';

class GeminiService {
  // TODO: Replace with your actual Gemini API Key
  static const String _apiKey = 'YOUR_API_KEY_HERE'; 
  late final GenerativeModel _model;

  GeminiService() {
    _model = GenerativeModel(model: 'gemini-1.5-flash', apiKey: _apiKey);
  }

  Future<String> generatePetCaption(Pet pet, String activity) async {
    try {
      final prompt = '''
        You are a ${pet.breed} named ${pet.name}. 
        Write a short social media caption (max 2 sentences) for a photo where you are: $activity.
        Use emojis. Write in the first person ("I").
      ''';
      final response = await _model.generateContent([Content.text(prompt)]);
      return response.text?.trim() ?? "Woof! Just living my best life.";
    } catch (e) {
      return "Just being cute today! 🐾";
    }
  }

  Future<String> analyzeHealthTip(Pet pet) async {
    try {
      final prompt = 'Give me a one-sentence health tip for a ${pet.breed}. Focus on preventive care.';
      final response = await _model.generateContent([Content.text(prompt)]);
      return response.text?.trim() ?? "Keep fresh water available at all times!";
    } catch (e) {
      return "Regular vet visits keep your pet happy!";
    }
  }

  Future<String> chatWithVet(String message, Pet pet) async {
    try {
      final prompt = '''
        You are a friendly AI Veterinary Assistant. User has a ${pet.breed} named ${pet.name}.
        Answer this question concisely (under 80 words): $message
        If serious, advise seeing a real vet.
      ''';
      final response = await _model.generateContent([Content.text(prompt)]);
      return response.text?.trim() ?? "I'm not sure, best to check with a local vet!";
    } catch (e) {
      return "I'm having trouble thinking right now. Try again later!";
    }
  }
  
  Future<String> predictFutureSelf(Pet pet) async {
     try {
      final prompt = 'Predict the future of a ${pet.breed} named ${pet.name} in 5 years. Be funny and horoscope-like. Max 2 sentences.';
      final response = await _model.generateContent([Content.text(prompt)]);
      return response.text?.trim() ?? "Still the goodest boy, just slower.";
    } catch (e) {
      return "Future unclear, ask again after treats.";
    }
  }
}
