import 'package:flutter/material.dart';

class AppTheme {
  static const Color primary = Color(0xFFF59E0B); // Amber 500
  static const Color background = Color(0xFFFFFBEB); // Amber 50
  static const Color surface = Colors.white;
  static const Color textMain = Color(0xFF1F2937);
  static const Color textSecondary = Color(0xFF6B7280);
}
