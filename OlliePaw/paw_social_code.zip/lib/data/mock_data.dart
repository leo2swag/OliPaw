import '../models/types.dart';

final Pet initialPet = Pet(
  id: 'p1',
  name: 'Barnaby',
  type: PetType.dog,
  breed: 'Golden Retriever',
  birthDate: '2021-05-10',
  avatarUrl: 'https://picsum.photos/id/1025/200/200',
  bio: 'Sock thief & Professional napper. 🧦',
  vaccines: [
    Vaccine(id: 'v1', name: 'Rabies', dateAdministered: '2023-05-10', dueDate: '2024-05-10', veterinarian: 'Dr. Smith'),
  ],
  weightHistory: [
    WeightRecord('Oct', 29.0),
    WeightRecord('Nov', 29.2),
    WeightRecord('Dec', 30.1),
    WeightRecord('Jan', 29.8),
  ],
  gallery: [
    'https://picsum.photos/id/237/300/300',
    'https://picsum.photos/id/1025/300/300',
    'https://picsum.photos/id/169/300/300',
  ],
);

final List<Pet> mockPets = [
  Pet(
    id: 'p2',
    name: 'Luna',
    type: PetType.dog,
    breed: 'Husky',
    birthDate: '2022-01-15',
    avatarUrl: 'https://picsum.photos/id/237/200/200',
    bio: 'I sing the song of my people at 3AM. 🐺',
    vaccines: [],
    weightHistory: [],
    gallery: ['https://picsum.photos/id/1062/300/300'],
  ),
  Pet(
    id: 'p3',
    name: 'Mochi',
    type: PetType.cat,
    breed: 'Scottish Fold',
    birthDate: '2020-08-20',
    avatarUrl: 'https://picsum.photos/id/40/200/200',
    bio: 'Judging you silently.',
    vaccines: [],
    weightHistory: [],
    gallery: ['https://picsum.photos/id/219/300/300'],
  ),
  Pet(
    id: 'p4',
    name: 'Charlie',
    type: PetType.dog,
    breed: 'Corgi',
    birthDate: '2023-01-01',
    avatarUrl: 'https://picsum.photos/id/200/200/200',
    bio: 'Short legs, big dreams.',
    vaccines: [],
    weightHistory: [],
    gallery: [],
  ),
];

final List<Post> mockPosts = [
  Post(
    id: 'post1',
    authorId: 'p2',
    authorName: 'Luna the Husky',
    authorAvatar: 'https://picsum.photos/id/237/100/100',
    content: 'Just sang the song of my people at 3AM. Humans loved it. 🎤',
    imageUrl: 'https://picsum.photos/id/1062/600/600',
    likes: 124,
    comments: 12,
    timestamp: '2h ago',
    date: '2023-10-25',
    category: PostCategory.snapshot,
    mood: 'Dramatic',
  ),
  Post(
    id: 'post2',
    authorId: 'p1',
    authorName: 'Barnaby',
    authorAvatar: 'https://picsum.photos/id/1025/100/100',
    content: 'Found a stick. It represents my authority.',
    likes: 89,
    comments: 5,
    timestamp: '5h ago',
    date: '2023-10-24',
    category: PostCategory.play,
    mood: 'Proud',
  ),
];
